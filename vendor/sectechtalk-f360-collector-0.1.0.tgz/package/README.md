# @sectechtalk/f360-collector

Reads every SAML, OpenID Connect and OAuth app from a Microsoft Entra ID tenant, **read-only**,
with its certificates, secrets (names and dates only), redirect URIs, owners and permissions.
It returns three things:

| Output | What it is | Who uses it |
|---|---|---|
| `raw` (`f360.entra.export` v1) | The Graph objects, key material stripped | f-360's Discover page, archives |
| `snapshot` | Provider-neutral apps: protocol, flow, SAML/OIDC facts, credentials, permissions | f-360 inventory merge, anything that lists apps |
| `credentials` (`f360.federation-credentials` v1) | One item per client secret, app certificate and SAML signing certificate, with status and days left | c-360's expiry view |

One copy of the code, built into each product's own image. f-360 and c-360 each ship as a single
container. No sidecar, nothing to network together.

No runtime dependencies. The library runs in a browser page and in Node 18+. The command-line
tool `f360-collect` is for containers and shells.

## How a product gets it (no registry, no token, $0)

Each release is one file: `release/sectechtalk-f360-collector-<version>.tgz`. A consumer copies
that file into its own repo under `vendor/` and depends on it by path:

```json
"dependencies": {
  "@sectechtalk/f360-collector": "file:vendor/sectechtalk-f360-collector-0.1.0.tgz"
}
```

and in its Dockerfile copies `vendor/` before `npm ci`:

```dockerfile
COPY package.json package-lock.json ./
COPY vendor ./vendor
RUN npm ci
```

Why this way: the Docker build needs no GitHub token and no package registry, so nothing can
bill and nothing can fail on credentials. The consumer's image is self-contained. Updating is
"copy the new .tgz, change the version in package.json, `npm install`, commit".

## Library

```ts
import { scanEntraTenant, makeSampleEntraExport, entraToSnapshot, credentialsFromSnapshot } from "@sectechtalk/f360-collector";

// Unattended (container): app-only sign-in
const { raw, snapshot, credentials } = await scanEntraTenant({
  tenantId: process.env.F360_TENANT_ID!,
  clientId: process.env.F360_CLIENT_ID!,
  clientSecret: process.env.F360_CLIENT_SECRET!,
});

// You already have a Graph token (browser sign-in, managed identity, az CLI)
await scanEntraTenant({ tenantId, token });

// Offline: a file from Export-F360EntraInventory.ps1
const creds = credentialsFromSnapshot(entraToSnapshot(JSON.parse(text)));

// No tenant: fictional sample shaped like the f-360 lab
const demo = credentialsFromSnapshot(entraToSnapshot(makeSampleEntraExport()));
```

Lower-level pieces: `collectEntraExport(token, tenantId, { onProgress })`, `getAppOnlyToken(...)`,
`entraAdapter`, `pickExpiry`, `credentialStatus`, `scannedCredentialId`, `entraManageUrl`,
`finishCredentialsExport`, `assertNoSecretMaterial`, and every type (`DiscoverySnapshot`,
`DiscoveredApp`, `CredentialItem`, `CredentialsExport`, ...).

## Command line (`f360-collect`)

```sh
# Scan and print the credentials export; also write all three files to /data
F360_TENANT_ID=<tenant-id> F360_CLIENT_ID=<client-id> F360_CLIENT_SECRET=<secret> \
  npx f360-collect --out-dir /data

npx f360-collect --sample                         # no tenant, fictional data
npx f360-collect --from-file f360-entra-export.json   # offline file from the PowerShell script
npx f360-collect --help
```

Progress goes to standard error, the JSON document to standard output. Exit codes: 0 done,
1 the scan failed, 2 missing or wrong settings.

## PowerShell collector

`powershell/Export-F360EntraInventory.ps1` signs in as a person (delegated, browser or device
code), sends GET requests only and writes `f360-entra-export.json`. Use it where a product is
not allowed to scan the tenant itself, then load the file (f-360 Discover page, or
`f360-collect --from-file`). Consumers can import its text with
`@sectechtalk/f360-collector/powershell/Export-F360EntraInventory.ps1`.

## The app registration an unattended scan needs

Microsoft Graph **application** permissions `Application.Read.All` and `Directory.Read.All`,
with admin consent. Both are read-only. Put the client secret in the container's environment
(`F360_CLIENT_SECRET`), never in the image. Graph never returns secret values, and this package
also drops certificate bodies and secret hints, so no output ever holds secret material.

## Credentials contract (v1)

Schema: `schema/f360-federation-credentials.v1.schema.json` (import it as
`@sectechtalk/f360-collector/schema/f360-federation-credentials.v1.schema.json`).

- `id` is the upsert key and is the same whether f-360 or a direct scan produced the item:
  `f360:<provider>:<tenantId>:<appId>:<app|sp>:<keyId>` for scanned credentials,
  `f360:recorded:<f360AppId>:<type>` for ones a person typed into f-360.
- `generator.name` is `f-360` (built from the f-360 inventory, may include recorded SCIM
  tokens) or `f360-collector` (built straight from a scan).
- From a direct scan, `app.f360Id` and `app.environment` are `null`.
- SCIM tokens never come from a scan: Graph's `synchronization/secrets` is write-only.
- `status`: `expired` (daysLeft < 0), `expiring` (0 to 30), `ok`, `unknown` (no expiry).
- `manageUrl`: the Entra admin center page where a person rotates it.

## Develop and release

```sh
npm install
npm test
npm run release      # tests, builds dist/, writes release/sectechtalk-f360-collector-<version>.tgz
```

Bump `version` in `package.json` and `PACKAGE_VERSION` in `src/credentials.ts` (a test checks
they match), add a line to `CHANGELOG.md`, run `npm run release`, commit the new `.tgz`.
