# Changelog

## 0.1.0 (2026-11-16)

- First release, extracted from f-360's Discover page code: Graph collector (any token),
  app-only sign-in, Entra mapper, provider-neutral snapshot, credentials export contract v1,
  PowerShell collector, `f360-collect` command line, fictional sample tenant.
- Credentials contract v1 now allows `generator.name: "f360-collector"` and `null` for
  `app.f360Id` and `app.environment`, so a direct scan fits the same schema as f-360's export.
