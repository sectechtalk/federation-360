<#
.SYNOPSIS
  Reads every SAML, OpenID Connect and OAuth app in an Entra tenant, read-only, and saves it
  as a file you load on Federation 360's Discover page, or convert with
  `f360-collect --from-file` (the offline option for c-360).

  Part of @sectechtalk/f360-collector. Edit it there, not in a consumer's copy.

.DESCRIPTION
  Signs you in with the Microsoft Graph PowerShell SDK and asks for two read-only delegated
  permissions: Application.Read.All and Directory.Read.All. It only sends GET requests.

  It reads:
    - app registrations (redirect URIs, identifier URIs, secret and certificate names and dates)
    - service principals (SAML mode, signing certificates, sign-in enabled, publisher)
    - owners of both
    - delegated consent grants and application permission assignments
    - the APIs those permissions point at, so permission IDs can be shown as names

  Graph never returns secret values. The script also drops certificate bodies and secret hints,
  so the output file holds names, IDs, URLs and dates only.

.EXAMPLE
  cd $HOME\Downloads
  ./Export-F360EntraInventory.ps1 -TenantId 00000000-0000-0000-0000-000000000000

.EXAMPLE
  # No browser window appeared? Sign in with a device code instead
  ./Export-F360EntraInventory.ps1 -TenantId 00000000-0000-0000-0000-000000000000 -UseDeviceCode

.EXAMPLE
  # Lab tenant ID read from lab/lab-values.json in your f-360 folder, file written to Downloads
  cd $HOME\f-360
  ~/Downloads/Export-F360EntraInventory.ps1 -OutFile $HOME\Downloads\f360-entra-export.json
#>
#Requires -Version 7.2
[CmdletBinding()]
param(
    # Directory (tenant) ID. Read from lab/lab-values.json in the current folder when omitted.
    [string]$TenantId,

    [string]$OutFile = (Join-Path (Get-Location) 'f360-entra-export.json'),

    # Sign in with a code at https://microsoft.com/devicelogin instead of a browser window.
    # Use it when no browser window appears, or on a machine without a browser.
    [switch]$UseDeviceCode,

    # Keep the Graph sign-in for this PowerShell window after the export.
    [switch]$StayConnected
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Same field lists as src/entra/export.ts in @sectechtalk/f360-collector
$appSelect = 'id,appId,displayName,createdDateTime,signInAudience,identifierUris,web,spa,publicClient,isFallbackPublicClient,passwordCredentials,keyCredentials,requiredResourceAccess,api,appRoles,tags'
$spSelect = 'id,appId,displayName,accountEnabled,appOwnerOrganizationId,servicePrincipalType,preferredSingleSignOnMode,preferredTokenSigningKeyThumbprint,loginUrl,replyUrls,servicePrincipalNames,keyCredentials,tags,notificationEmailAddresses,publisherName,verifiedPublisher,appRoleAssignmentRequired'
$resourceSelect = 'id,appId,displayName,servicePrincipalNames,oauth2PermissionScopes,appRoles'
$ownerSelect = 'id,displayName,userPrincipalName,appId'
$microsoftTenants = @('f8cdef31-a31e-4b4a-93e4-5f571e91255a', '72f988bf-86f1-41af-91ab-2d7cd011db47')

if (-not $TenantId) {
    $valuesPath = Join-Path (Get-Location) 'lab' 'lab-values.json'
    if (Test-Path $valuesPath) { $TenantId = (Get-Content -Raw $valuesPath | ConvertFrom-Json -AsHashtable)['tenantId'] }
}
if ($TenantId -notmatch '^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$') {
    throw 'Pass -TenantId with your Directory (tenant) ID (a GUID). Find it in the Entra admin center under Entra ID > Overview.'
}

if (-not (Get-Module -ListAvailable Microsoft.Graph.Authentication)) {
    Write-Host 'Installing the Microsoft.Graph.Authentication module for your user (one time)...' -ForegroundColor Cyan
    Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber
}
Import-Module Microsoft.Graph.Authentication

# On Windows the module signs in through Web Account Manager (WAM) by default. Its window often opens
# hidden behind the terminal, and closing or missing it fails with "User canceled authentication".
# A normal browser tab is more reliable, so turn WAM off (this only changes the Graph module's setting).
if (Get-Command Set-MgGraphOption -ErrorAction SilentlyContinue) {
    try { Set-MgGraphOption -DisableLoginByWAM $true } catch { Write-Verbose "Could not turn off WAM: $_" }
}

$connect = @{
    TenantId     = $TenantId
    Scopes       = @('Application.Read.All', 'Directory.Read.All')
    NoWelcome    = $true
    ContextScope = 'Process'
}
if ($UseDeviceCode) { $connect['UseDeviceCode'] = $true }

Write-Host "Signing in to tenant $TenantId (read-only: Application.Read.All, Directory.Read.All)..." -ForegroundColor Cyan
if ($UseDeviceCode) { Write-Host 'Open https://microsoft.com/devicelogin and enter the code shown below.' }
else { Write-Host 'A browser tab opens for sign-in. Use a Global Administrator of this tenant.' }
try {
    Connect-MgGraph @connect
}
catch {
    Write-Host ''
    Write-Host "Sign-in didn't finish: $($_.Exception.Message)" -ForegroundColor Yellow
    if (-not $UseDeviceCode) {
        Write-Host 'Run the same command again with -UseDeviceCode added. It signs in with a code at https://microsoft.com/devicelogin, with no pop-up window.' -ForegroundColor Yellow
    }
    throw
}

function Get-GraphAll([string]$Uri) {
    $items = [System.Collections.Generic.List[object]]::new()
    $next = $Uri
    while ($next) {
        $page = Invoke-MgGraphRequest -Method GET -Uri $next -OutputType Json | ConvertFrom-Json -AsHashtable -Depth 50
        if ($page['value']) { $items.AddRange([object[]]$page['value']) }
        $next = $page['@odata.nextLink']
    }
    , $items.ToArray()
}

# Runs GETs through $batch, 20 per request. Returns one result per URL ($null when that call failed).
function Invoke-GraphBatch([string[]]$Urls) {
    $results = [object[]]::new($Urls.Count)
    for ($i = 0; $i -lt $Urls.Count; $i += 20) {
        $chunk = $Urls[$i..([Math]::Min($i + 19, $Urls.Count - 1))]
        $requests = for ($k = 0; $k -lt $chunk.Count; $k++) { @{ id = "$k"; method = 'GET'; url = $chunk[$k] } }
        $body = @{ requests = @($requests) } | ConvertTo-Json -Depth 5
        $resp = Invoke-MgGraphRequest -Method POST -Uri 'v1.0/$batch' -Body $body -ContentType 'application/json' -OutputType Json |
            ConvertFrom-Json -AsHashtable -Depth 50
        foreach ($r in $resp['responses']) {
            if ($r['status'] -eq 200) {
                $b = $r['body']
                $results[$i + [int]$r['id']] = if ($b.ContainsKey('value')) { , $b['value'] } else { $b }
            }
            else {
                Write-Warning "Skipped $($chunk[[int]$r['id']]): HTTP $($r['status'])"
            }
        }
    }
    , $results
}

function Remove-KeyMaterial($o) {
    if ($o['keyCredentials']) { foreach ($k in $o['keyCredentials']) { $k.Remove('key') } }
    if ($o['passwordCredentials']) { foreach ($p in $o['passwordCredentials']) { $p.Remove('hint'); $p.Remove('secretText') } }
    $o
}

try {
    Write-Host 'Reading the organization...'
    $org = (Get-GraphAll 'v1.0/organization?$select=id,displayName,verifiedDomains')[0]
    $tid = $org['id']

    Write-Host 'Reading app registrations...'
    $applications = Get-GraphAll "v1.0/applications?`$select=$appSelect&`$top=999"
    Write-Host "  $($applications.Count) app registrations"

    Write-Host 'Reading service principals...'
    $servicePrincipals = Get-GraphAll "v1.0/servicePrincipals?`$select=$spSelect&`$top=100"
    Write-Host "  $($servicePrincipals.Count) service principals"

    # Same rule as isCandidateSp in src/lib/discovery/entra.ts
    $candidates = @($servicePrincipals | Where-Object {
            $type = $_['servicePrincipalType']; $ownerOrg = "$($_['appOwnerOrganizationId'])".ToLower()
            (-not $type -or $type -eq 'Application') -and ($ownerOrg -notin $microsoftTenants) -and (
                $ownerOrg -eq $tid.ToLower() -or
                (@($_['tags']) -contains 'WindowsAzureActiveDirectoryIntegratedApp') -or
                $_['preferredSingleSignOnMode'] -in @('saml', 'oidc'))
        })

    Write-Host "Reading owners for $($applications.Count + $candidates.Count) objects..."
    if ($applications.Count) {
        $owners = Invoke-GraphBatch @($applications | ForEach-Object { "/applications/$($_['id'])/owners?`$select=$ownerSelect" })
        for ($i = 0; $i -lt $applications.Count; $i++) { $applications[$i]['owners'] = @($owners[$i] ?? @()) }
    }
    if ($candidates.Count) {
        $owners = Invoke-GraphBatch @($candidates | ForEach-Object { "/servicePrincipals/$($_['id'])/owners?`$select=$ownerSelect" })
        for ($i = 0; $i -lt $candidates.Count; $i++) { $candidates[$i]['owners'] = @($owners[$i] ?? @()) }
    }

    Write-Host 'Reading consent grants and app role assignments...'
    $grants = Get-GraphAll 'v1.0/oauth2PermissionGrants'
    $assignments = @()
    if ($candidates.Count) {
        $assignments = @((Invoke-GraphBatch @($candidates | ForEach-Object { "/servicePrincipals/$($_['id'])/appRoleAssignments" })) |
            Where-Object { $_ } | ForEach-Object { $_ })
    }

    $spById = @{}; foreach ($sp in $servicePrincipals) { $spById[$sp['id']] = $sp }
    $resourceAppIds = [System.Collections.Generic.HashSet[string]]::new()
    foreach ($a in $applications) { foreach ($r in @($a['requiredResourceAccess'])) { if ($r) { [void]$resourceAppIds.Add($r['resourceAppId']) } } }
    foreach ($x in @($grants) + @($assignments)) { if ($x -and $spById.ContainsKey($x['resourceId'])) { [void]$resourceAppIds.Add($spById[$x['resourceId']]['appId']) } }

    Write-Host "Resolving permission names on $($resourceAppIds.Count) APIs..."
    $resources = @()
    if ($resourceAppIds.Count) {
        $resources = @((Invoke-GraphBatch @($resourceAppIds | ForEach-Object { "/servicePrincipals(appId='$_')?`$select=$resourceSelect" })) | Where-Object { $_ })
    }

    $export = [ordered]@{
        format                    = 'f360.entra.export'
        version                   = 1
        collectedAt               = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        collector                 = 'powershell'
        tenantId                  = $tid
        organization              = $org
        applications              = @($applications | ForEach-Object { Remove-KeyMaterial $_ })
        servicePrincipals         = @($servicePrincipals | ForEach-Object { Remove-KeyMaterial $_ })
        resourceServicePrincipals = $resources
        oauth2PermissionGrants    = @($grants)
        appRoleAssignments        = $assignments
    }
    $export | ConvertTo-Json -Depth 50 -Compress | Set-Content -Path $OutFile -Encoding utf8NoBOM
    $full = (Resolve-Path $OutFile).Path
    Write-Host ''
    Write-Host "Saved $full" -ForegroundColor Green
    Write-Host "  $($applications.Count) app registrations, $($candidates.Count) enterprise apps, $($grants.Count) consent grants, $($assignments.Count) app role assignments"
    Write-Host 'Next: Federation 360 > Discover > Load export file, and pick this file.'
}
finally {
    if (-not $StayConnected) { Disconnect-MgGraph | Out-Null }
}
